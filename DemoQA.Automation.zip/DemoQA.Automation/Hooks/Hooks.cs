﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using TechTalk.SpecFlow;

namespace DemoQA.Automation.Hooks
{
    [Binding]
    public class Hooks
    {
        private readonly ScenarioContext _scenarioContext;

        public Hooks(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        [BeforeScenario]
        public void BeforeScenario()
        {
            // Initialize ChromeDriver
            IWebDriver driver = new ChromeDriver();

            // Maximize window (optional)
            driver.Manage().Window.Maximize();

            // Add driver to ScenarioContext
            _scenarioContext["driver"] = driver;
        }

        [AfterScenario]
        public void AfterScenario()
        {
            if (_scenarioContext.ContainsKey("driver"))
            {
                var driver = _scenarioContext.Get<IWebDriver>("driver");
                driver.Quit();
            }
        }
    }
}
