﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using System;

namespace DemoQA.Automation.Pages
{
    public class WebTablesPage
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _wait;

        public WebTablesPage(IWebDriver driver)
        {
            _driver = driver;
            _wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(10));
        }

        // 1️⃣ Navigate to Web Tables page
        public void NavigateToWebTablesPage()
        {
            _driver.Navigate().GoToUrl("https://demoqa.com/webtables");

            // Remove any overlay or banners
            var banners = _driver.FindElements(By.Id("fixedban"));
            if (banners.Count > 0)
            {
                ((IJavaScriptExecutor)_driver).ExecuteScript("arguments[0].style.display='none';", banners[0]);
            }

            // Wait until the Add button is clickable
            _wait.Until(ExpectedConditions.ElementToBeClickable(By.Id("addNewRecordButton")));
        }

        // 2️⃣ Add new record
        public void AddNewRecord(string firstName = "John", string lastName = "Doe", string email = "john.doe@example.com",
                                 string age = "30", string salary = "50000", string department = "QA")
        {
            _driver.FindElement(By.Id("addNewRecordButton")).Click();

            _wait.Until(ExpectedConditions.ElementIsVisible(By.Id("firstName")));

            _driver.FindElement(By.Id("firstName")).Clear();
            _driver.FindElement(By.Id("firstName")).SendKeys(firstName);

            _driver.FindElement(By.Id("lastName")).Clear();
            _driver.FindElement(By.Id("lastName")).SendKeys(lastName);

            _driver.FindElement(By.Id("userEmail")).Clear();
            _driver.FindElement(By.Id("userEmail")).SendKeys(email);

            _driver.FindElement(By.Id("age")).Clear();
            _driver.FindElement(By.Id("age")).SendKeys(age);

            _driver.FindElement(By.Id("salary")).Clear();
            _driver.FindElement(By.Id("salary")).SendKeys(salary);

            _driver.FindElement(By.Id("department")).Clear();
            _driver.FindElement(By.Id("department")).SendKeys(department);

            _driver.FindElement(By.Id("submit")).Click();

            // Wait until the form disappears
            _wait.Until(ExpectedConditions.InvisibilityOfElementLocated(By.Id("firstName")));
        }

        // 3️⃣ Edit first record
        public void EditFirstRecord(string newFirstName = "Jane")
        {
            _wait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector(".action-buttons span[title='Edit']")));
            _driver.FindElement(By.CssSelector(".action-buttons span[title='Edit']")).Click();

            _wait.Until(ExpectedConditions.ElementIsVisible(By.Id("firstName")));
            var firstNameInput = _driver.FindElement(By.Id("firstName"));
            firstNameInput.Clear();
            firstNameInput.SendKeys(newFirstName);

            _driver.FindElement(By.Id("submit")).Click();

            _wait.Until(ExpectedConditions.InvisibilityOfElementLocated(By.Id("firstName")));
        }

        // 4️⃣ Delete first record
        public void DeleteFirstRecord()
        {
            _wait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector(".action-buttons span[title='Delete']")));
            _driver.FindElement(By.CssSelector(".action-buttons span[title='Delete']")).Click();
        }

        // 5️⃣ Verification methods
        public bool IsRecordPresent()
        {
            try
            {
                var rows = _driver.FindElements(By.CssSelector(".rt-tr-group"));
                return rows.Count > 0;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

        public bool IsRecordUpdated(string expectedFirstName = "Jane")
        {
            try
            {
                return _driver.FindElement(By.XPath($"//div[text()='{expectedFirstName}']")).Displayed;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

        public bool IsRecordDeleted()
        {
            var rows = _driver.FindElements(By.CssSelector(".rt-tr-group"));
            return rows.Count == 0;
        }
    }
}
