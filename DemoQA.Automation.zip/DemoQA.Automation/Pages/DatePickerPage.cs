﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;

namespace DemoQA.Automation.Pages
{
    public class DatePickerPage
    {
        private readonly IWebDriver _driver;

        public DatePickerPage(IWebDriver driver)
        {
            _driver = driver;
        }

        // 1️⃣ Navigate to the Date Picker page
        public void NavigateToDatePickerPage()
        {
            // Navigate to the page
            _driver.Navigate().GoToUrl("https://demoqa.com/date-picker");

            // Wait until the date input is visible
            var wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(10));
            wait.Until(d => d.FindElement(By.Id("datePickerMonthYearInput")));
        }

        // 2️⃣ Select a day dynamically
        public void SelectDate(int day)
        {
            _driver.FindElement(By.Id("datePickerMonthYearInput")).Click();
            var dayLocator = By.CssSelector($".react-datepicker__day--0{day:D2}");
            _driver.FindElement(dayLocator).Click();
        }

        // 3️⃣ Get the selected date
        public string GetSelectedDate()
        {
            return _driver.FindElement(By.Id("datePickerMonthYearInput")).GetAttribute("value") ?? string.Empty;
        }
    }
}
